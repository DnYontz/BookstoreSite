<?
    include('header.html');
    
    $user = '2210629_users';
    $pass = 'its9260122';
    $db = new PDO("mysql:host=pdb3.awardspace.net;dbname=2210629_users",$user,$pass);
    
    if($db){
        echo "Connection Successful";
    } else {
        die("Connection Unsuccessful");
    }
    
    if($_SERVER["REQUEST_METHOD"] == "POST"){
        
        if(isset($_POST["login"])){
            echo 'login';
        }
        if(isset($_POST["admin"])){
            echo 'admin';
        }
        if(isset($_POST["search"])){
            echo 'search';
        }
    }

    if(isset($_POST['username'])){
        $username = $_POST['username'];
    } else {
        $username = NULL;
    }
    if(isset($_POST['password'])){
        $password = $_POST['password'];
        if(strlen($password) < 8){
            echo "Password must contain at least 8 characters.";
            $password = NULL;
        }
    } else {
        $password = NULL;
    }
    
    $admin = "FALSE";
    if(isset($_POST['admin'])){
        $admin = $_POST['admin'];
    }
    
    if ($admin == "TRUE"){
        include('nav2.html');
    } else {
        include('nav.html');
    }
    
    if ($username != NULL && $password != NULL){
        include('loggedin.html');
        
    } else {
        include('login.html');
    }
        
        //$r = $db->query("SELECT * FROM useraccts WHERE Username =".$username);
        
        //$db->query("INSERT INTO useraccts (UserName,pass) VALUES ('".$username."','".$password."');");
    
    if (isset($_POST['search'])){
        $results = $_POST['search'];
    } else {
        $results = NULL;
    }
    
    include('search.html');
    include('results.html');
    include('footer.html');
    
?>