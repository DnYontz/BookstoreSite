<?
    include('header.html');
    include('nav.html');
    include('footer.html');
?>