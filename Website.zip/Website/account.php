<?
    include('header.html');
    include('nav2.html');
?>

<h1>Welcome!</h1>
<? include('footer.html'); ?>