<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    
        <?php
        // put your code here
        ?>
        
        <!-- Adding a Book form for Admin -->
        <h1>Add a Book</h1>
        <div align="center">
        <form action="add_book.php" method="post">
            <fieldset><legend>Fill out the form to add a book to your inventory:</legend>
                <p><b>Book Title:</b><input type="text" name="book_title" size="10" maxlength="50" value="<?php if (isset($_POST['book_title'])) echo $_POST['book_title']; ?>" /></p>            
                <p><b>Author:</b><input type="text" name="author_name" size="10" maxlength="50" value="<?php if (isset($_POST['author_name'])) echo $_POST['author_name']; ?>" /></p>
                <p><b>Genre:</b><input type="text" name="book_genre" size="10" maxlength="50" value="<?php if (isset($_POST['book_genre'])) echo $_POST['book_genre']; ?>" /></p>
                <p><b>Year Published:</b><input type="text" name="year_published" size="10" maxlength="50" value="<?php if (isset($_POST['year_published'])) echo $_POST['year_published']; ?>" /></p> 
                <p><b>Price:</b><input type="text" name="book_price" size="10" maxlength="50" value="<?php if (isset($_POST['book_price'])) echo $_POST['book_price']; ?>" /></p>                 
            </fieldset><input type ="submit" name="submit" value="submit" />
        </form></div>
    
</html>
