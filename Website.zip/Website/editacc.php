<?
    include('header.html');
    include('nav.html');
?>

<form action="account.php">
    <label>First Name<input type="text" name="fname"></label><br>
    <label>Last Name<input type="text" name="lname"></label><br>
    <label>Blah blah<input type="text" name="blah"></label><br>
    <input type="submit" value="Update">
</form>
<? include('footer.html'); ?>